import fs from 'node:fs'
import path from 'node:path'

const stage = path.resolve(process.argv[2] ?? 'build/runtime')
const required = [
  'bootstrap.mjs',
  'android.cordis.patch.yml',
  'MOBILE_RUNTIME_INFO.json',
  'node_modules/@deepseek-ai/dsh/lib/bin.js',
  'node_modules/@deepseek-ai/dsh/config/agent-presets/standard/agent.cordis.yml',
  'node_modules/@deepseek-ai/dsh-subprocess-local/lib/index.js',
  'node_modules/@deepseek-ai/dsh-bash-local/lib/index.js',
  'node_modules/@deepseek-ai/dsh-bash-sandbox/lib/index.js',
  'node_modules/@deepseek-ai/dsh-sandbox-local/lib/index.js'
]

for (const rel of required) {
  const p = path.join(stage, rel)
  if (!fs.existsSync(p)) throw new Error(`Runtime verification failed: missing ${rel}`)
}

const subproc = fs.readFileSync(
  path.join(stage, 'node_modules/@deepseek-ai/dsh-subprocess-local/lib/index.js'),
  'utf8'
)
if (/from\s+["']node-pty["']/.test(subproc)) {
  throw new Error('Runtime verification failed: node-pty is still imported')
}

for (const pkg of ['@deepseek-ai/dsh-bash-local', '@deepseek-ai/dsh-bash-sandbox']) {
  const p = path.join(stage, 'node_modules', ...pkg.split('/'), 'lib', 'index.js')
  const s = fs.readFileSync(p, 'utf8')
  if (!s.includes('/system/bin/sh')) {
    throw new Error(`Runtime verification failed: Android shell patch missing in ${pkg}`)
  }
}

const sandbox = fs.readFileSync(
  path.join(stage, 'node_modules/@deepseek-ai/dsh-sandbox-local/lib/index.js'),
  'utf8'
)
if (!sandbox.includes('AndroidSandboxProvider')) {
  throw new Error('Runtime verification failed: Android sandbox provider missing')
}

console.log('Runtime verification passed')
