#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <nodejs-mobile-checkout>"
  exit 2
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_MOBILE="$(cd "$1" && pwd)"

LIB="$NODE_MOBILE/out_android/arm64-v8a/libnode.so"
HEADERS="$NODE_MOBILE/out_android/libnode/include/node"

test -f "$LIB"
test -d "$HEADERS"

mkdir -p "$ROOT/app/src/main/jniLibs/arm64-v8a"
rm -rf "$ROOT/app/src/main/cpp/node-include"
mkdir -p "$ROOT/app/src/main/cpp/node-include"

cp "$LIB" "$ROOT/app/src/main/jniLibs/arm64-v8a/libnode.so"
cp -R "$HEADERS/"* "$ROOT/app/src/main/cpp/node-include/"

echo "Installed Node mobile artifacts into Android project"
