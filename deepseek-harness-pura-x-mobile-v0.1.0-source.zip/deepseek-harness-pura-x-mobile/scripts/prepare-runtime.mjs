import fs from 'node:fs'
import path from 'node:path'

const stage = path.resolve(process.argv[2] ?? 'build/runtime')
const nodeModules = path.join(stage, 'node_modules')

function mustFile(p) {
  if (!fs.existsSync(p)) throw new Error(`Required file missing: ${p}`)
  return p
}

function packageDir(name) {
  const direct = path.join(nodeModules, ...name.split('/'))
  if (fs.existsSync(direct)) return direct
  throw new Error(`Package not found in staged runtime: ${name}`)
}

function patchShArgv(packageName) {
  const file = mustFile(path.join(packageDir(packageName), 'lib', 'index.js'))
  let source = fs.readFileSync(file, 'utf8')
  const before = source

  // Published bundles can use either quote style/spacing. Replace only argv
  // pairs whose first two elements are bash and -c.
  source = source.replace(
    /(["'])bash\1\s*,\s*(["'])-c\2/g,
    '"/system/bin/sh", "-c"'
  )

  if (source === before) {
    throw new Error(`Could not locate bash -c argv in ${file}; DSH package layout changed`)
  }
  fs.writeFileSync(file, source)
  console.log(`Patched Android shell argv: ${packageName}`)
}

function patchNodePtyImport() {
  const file = mustFile(path.join(packageDir('@deepseek-ai/dsh-subprocess-local'), 'lib', 'index.js'))
  let source = fs.readFileSync(file, 'utf8')
  const before = source

  // The current source is `import * as nodePty from 'node-pty'`.
  // Keep this robust against quote/minifier variations while preserving the
  // imported identifier expected later in spawnTerminal().
  const patterns = [
    {
      re: /^import\s+\*\s+as\s+([A-Za-z_$][\w$]*)\s+from\s+["']node-pty["'];?\s*$/m,
      make: m => `const ${m[1]} = { spawn() { throw new Error("Persistent PTY is not enabled in the Android V1 runtime") } };`
    },
    {
      re: /^import\s+([A-Za-z_$][\w$]*)\s+from\s+["']node-pty["'];?\s*$/m,
      make: m => `const ${m[1]} = { spawn() { throw new Error("Persistent PTY is not enabled in the Android V1 runtime") } };`
    }
  ]

  let changed = false
  for (const { re, make } of patterns) {
    const m = source.match(re)
    if (m) {
      source = source.replace(re, make(m))
      changed = true
      break
    }
  }

  if (!changed) {
    throw new Error(`Could not locate node-pty import in ${file}; DSH package layout changed`)
  }
  fs.writeFileSync(file, source)

  // It is now unreachable. Remove desktop native binaries from the mobile asset.
  const pty = path.join(nodeModules, 'node-pty')
  fs.rmSync(pty, { recursive: true, force: true })
  console.log('Disabled desktop node-pty import for Android V1')
}

function replaceSandboxLocal() {
  const file = mustFile(path.join(packageDir('@deepseek-ai/dsh-sandbox-local'), 'lib', 'index.js'))
  const stub = `
// Android mobile compatibility provider.
// The APK itself runs under Android's per-app UID sandbox and requests no
// broad/shared-storage permission. DSH "danger-full-access" means full access
// *inside that Android app sandbox*. If a session requests a confined DSH mode,
// fail closed rather than pretending Android provides Landlock/bwrap.
import { SandboxProvider, SandboxUnavailableError } from '@deepseek-ai/dsh-sandbox';

export class AndroidSandboxProvider extends SandboxProvider {
  constructor(ctx) { super(ctx); }
  confine(argv, policy) {
    throw new SandboxUnavailableError(
      policy.mode,
      'This APK does not ship bwrap/Landlock. Use danger-full-access inside the Android app sandbox.'
    );
  }
}

export default AndroidSandboxProvider;
`.trimStart()
  fs.writeFileSync(file, stub)

  // Native desktop/Linux confinement helper is no longer reachable.
  const landlock = path.join(nodeModules, '@deepseek-ai', 'node-addon-landlock-run')
  fs.rmSync(landlock, { recursive: true, force: true })
  console.log('Replaced desktop sandbox backend with Android fail-closed provider')
}

function disablePackagedRipgrepInStandardPreset() {
  const file = mustFile(path.join(packageDir('@deepseek-ai/dsh'), 'config', 'agent-presets', 'standard', 'agent.cordis.yml'))
  let source = fs.readFileSync(file, 'utf8')
  const marker = `- id: tool-fs-search\n  name: '@deepseek-ai/dsh-tool-fs-search'`
  if (!source.includes(marker)) {
    throw new Error(`Could not locate standard preset fs-search row: ${file}`)
  }
  source = source.replace(marker, `${marker}\n  disabled: true`)
  fs.writeFileSync(file, source)
  console.log('Disabled packaged ripgrep search in Android standard preset')
}

function writeBootstrap() {
  const content = `
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const appRoot = path.resolve(process.argv[2])
const runtimeRoot = path.dirname(new URL(import.meta.url).pathname)
const workspace = path.join(appRoot, 'workspace')
const dshHome = path.join(appRoot, 'dsh-home')
const tmp = path.join(appRoot, 'tmp')
const home = path.join(appRoot, 'home')

for (const dir of [workspace, dshHome, tmp, home]) {
  fs.mkdirSync(dir, { recursive: true })
}

process.env.DSH_HOME = dshHome
process.env.HOME = home
process.env.TMPDIR = tmp
process.env.TMP = tmp
process.env.TEMP = tmp
process.env.SHELL = '/system/bin/sh'
process.env.PATH = ['/system/bin', '/system/xbin', process.env.PATH ?? ''].filter(Boolean).join(':')
process.env.DSH_PERMISSION_MODE = 'danger-full-access'
process.env.DSH_TELEMETRY_DISABLED = '1'
process.env.DSH_TOOLS_MODE = process.env.DSH_TOOLS_MODE || 'native'

process.chdir(workspace)

const dshBin = path.join(runtimeRoot, 'node_modules', '@deepseek-ai', 'dsh', 'lib', 'bin.js')
const mobilePatch = path.join(runtimeRoot, 'android.cordis.patch.yml')

// dsh's launcher flags must precede app-owned Web flags.
process.argv = [
  process.execPath || 'node',
  dshBin,
  'web',
  '--patch',
  mobilePatch,
  '--port',
  '3080'
]

await import(pathToFileURL(dshBin).href)
`.trimStart()
  fs.writeFileSync(path.join(stage, 'bootstrap.mjs'), content)
}

function writeMobilePatch() {
  const content = `
# Android APK deployment overlay.
# Keep explicit approval even though process confinement is delegated to the
# Android application sandbox and DSH runs in danger-full-access mode.
- id: approval
  config:
    policy: ask

# A native desktop "open document" target does not exist inside 卓易通.
- id: api-gateway
  config:
    nativeOpen: false
    sessionExportCompressionLevel: 6
    coldBlankProbeMaxBytes: 1024
`.trimStart()
  fs.writeFileSync(path.join(stage, 'android.cordis.patch.yml'), content)
}

patchNodePtyImport()
patchShArgv('@deepseek-ai/dsh-bash-local')
patchShArgv('@deepseek-ai/dsh-bash-sandbox')
replaceSandboxLocal()
disablePackagedRipgrepInStandardPreset()
writeBootstrap()
writeMobilePatch()

fs.writeFileSync(
  path.join(stage, 'MOBILE_RUNTIME_INFO.json'),
  JSON.stringify({
    harness: '0.1.0-rc.7',
    nodeMobile: '24.5.0',
    abi: 'arm64-v8a',
    shell: '/system/bin/sh',
    persistentPty: false,
    packagedRipgrep: false
  }, null, 2) + '\n'
)

console.log('Android DeepSeek Harness runtime prepared:', stage)
