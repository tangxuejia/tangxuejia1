#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STAGE="$ROOT/build/runtime"
ASSET="$ROOT/app/src/main/assets/dsh-runtime.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE"

cat > "$STAGE/package.json" <<'JSON'
{
  "private": true,
  "name": "deepseek-harness-mobile-runtime",
  "version": "0.1.0"
}
JSON

cd "$STAGE"
npm install --omit=dev --no-audit --no-fund @deepseek-ai/dsh@0.1.0-rc.7

cd "$ROOT"
node scripts/prepare-runtime.mjs "$STAGE"
node scripts/verify-runtime.mjs "$STAGE"

rm -f "$ASSET"
cd "$STAGE"
zip -q -r -9 "$ASSET" .

echo "Created $ASSET"
du -h "$ASSET"
