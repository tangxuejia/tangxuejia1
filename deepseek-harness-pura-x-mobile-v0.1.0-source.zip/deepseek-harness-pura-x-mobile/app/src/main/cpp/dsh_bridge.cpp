#include <jni.h>
#include <android/log.h>
#include <node.h>

#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#define LOG_TAG "DshNode"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C"
JNIEXPORT jint JNICALL
Java_com_tang_dshmobile_NodeBridge_startNodeWithArguments(
        JNIEnv* env,
        jclass,
        jobjectArray arguments) {
    const jsize count = env->GetArrayLength(arguments);
    if (count <= 0) {
        LOGE("No Node arguments supplied");
        return -1;
    }

    std::vector<std::string> values;
    values.reserve(static_cast<size_t>(count));
    size_t bytes = 0;

    for (jsize i = 0; i < count; ++i) {
        auto item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        const char* utf = env->GetStringUTFChars(item, nullptr);
        if (utf == nullptr) return -2;
        values.emplace_back(utf);
        bytes += values.back().size() + 1;
        env->ReleaseStringUTFChars(item, utf);
        env->DeleteLocalRef(item);
    }

    // libuv/Node expects argv strings in contiguous mutable memory.
    std::vector<char> buffer(bytes, '\0');
    std::vector<char*> argv(static_cast<size_t>(count));
    char* cursor = buffer.data();
    for (jsize i = 0; i < count; ++i) {
        const auto& value = values[static_cast<size_t>(i)];
        std::memcpy(cursor, value.c_str(), value.size());
        argv[static_cast<size_t>(i)] = cursor;
        cursor += value.size() + 1;
    }

    LOGI("Starting embedded Node.js with %d args", static_cast<int>(count));
    const int exitCode = node::Start(static_cast<int>(count), argv.data());
    LOGI("Embedded Node.js exited with %d", exitCode);
    return static_cast<jint>(exitCode);
}
