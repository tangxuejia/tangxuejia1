package com.tang.dshmobile;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

final class RuntimeInstaller {
    private static final String ASSET = "dsh-runtime.zip";
    private static final String VERSION = "dsh-0.1.0-rc.7-node24.5-mobile-v1";
    private static final String STAMP = ".runtime-version";

    private RuntimeInstaller() {}

    static File install(Context context) throws IOException {
        File target = new File(context.getFilesDir(), "dsh-runtime");
        File stamp = new File(target, STAMP);
        if (target.isDirectory() && stamp.isFile()) {
            String value = Files.readString(stamp.toPath(), StandardCharsets.UTF_8).trim();
            if (VERSION.equals(value)) return target;
        }

        File temp = new File(context.getFilesDir(), "dsh-runtime.tmp");
        deleteTree(temp);
        if (!temp.mkdirs() && !temp.isDirectory()) {
            throw new IOException("Cannot create runtime temp directory: " + temp);
        }

        try (InputStream raw = context.getAssets().open(ASSET);
             ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry entry;
            byte[] buffer = new byte[64 * 1024];
            String rootPath = temp.getCanonicalPath() + File.separator;

            while ((entry = zin.getNextEntry()) != null) {
                File out = new File(temp, entry.getName());
                String canonical = out.getCanonicalPath();
                if (!canonical.startsWith(rootPath)) {
                    throw new IOException("Unsafe ZIP path: " + entry.getName());
                }

                if (entry.isDirectory()) {
                    if (!out.mkdirs() && !out.isDirectory()) {
                        throw new IOException("Cannot create runtime directory: " + out);
                    }
                } else {
                    File parent = out.getParentFile();
                    if (parent != null && !parent.mkdirs() && !parent.isDirectory()) {
                        throw new IOException("Cannot create runtime parent: " + parent);
                    }
                    try (BufferedOutputStream bout =
                                 new BufferedOutputStream(new FileOutputStream(out))) {
                        int n;
                        while ((n = zin.read(buffer)) != -1) {
                            bout.write(buffer, 0, n);
                        }
                    }
                }
                zin.closeEntry();
            }
        }

        Files.writeString(new File(temp, STAMP).toPath(), VERSION,
                StandardCharsets.UTF_8);

        deleteTree(target);
        try {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception ignored) {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
        return target;
    }

    static void deleteTree(File root) throws IOException {
        if (root == null || !root.exists()) return;
        File[] children = root.listFiles();
        if (children != null) {
            for (File child : children) deleteTree(child);
        }
        if (!root.delete() && root.exists()) {
            throw new IOException("Cannot delete: " + root);
        }
    }
}
