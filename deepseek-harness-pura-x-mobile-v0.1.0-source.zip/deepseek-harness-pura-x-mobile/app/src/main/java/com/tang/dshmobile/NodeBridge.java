package com.tang.dshmobile;

public final class NodeBridge {
    static {
        System.loadLibrary("node");
        System.loadLibrary("dsh_bridge");
    }

    private NodeBridge() {}

    public static native int startNodeWithArguments(String[] arguments);
}
