package com.tang.dshmobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final String HARNESS_URL = "http://127.0.0.1:3080/";
    private static final int REQ_IMPORT = 1001;
    private static final int REQ_EXPORT = 1002;
    private static final AtomicBoolean NODE_STARTED = new AtomicBoolean(false);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private TextView status;
    private ProgressBar progress;
    private File workspace;
    private int retryCount = 0;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        buildUi();

        workspace = new File(getFilesDir(), "workspace");
        if (!workspace.mkdirs() && !workspace.isDirectory()) {
            showFatal("无法创建工作区：" + workspace);
            return;
        }

        configureWebView();
        startHarness();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(dp(4), dp(2), dp(4), dp(2));

        Button importButton = new Button(this);
        importButton.setText("导入 ZIP");
        importButton.setAllCaps(false);
        importButton.setOnClickListener(v -> openImportPicker());

        Button exportButton = new Button(this);
        exportButton.setText("导出 ZIP");
        exportButton.setAllCaps(false);
        exportButton.setOnClickListener(v -> openExportPicker());

        Button reloadButton = new Button(this);
        reloadButton.setText("刷新");
        reloadButton.setAllCaps(false);
        reloadButton.setOnClickListener(v -> webView.loadUrl(HARNESS_URL));

        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(0, dp(44), 1f);
        toolbar.addView(importButton, buttonParams);
        toolbar.addView(exportButton, buttonParams);
        toolbar.addView(reloadButton, buttonParams);
        root.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        webView = new WebView(this);
        content.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.WHITE);
        overlay.setTag("loading-overlay");
        content.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        progress = new ProgressBar(this);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(56), dp(56));
        p.gravity = Gravity.CENTER;
        overlay.addView(progress, p);

        status = new TextView(this);
        status.setText(getString(R.string.loading));
        status.setTextColor(Color.DKGRAY);
        status.setTextSize(15f);
        status.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams t = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t.gravity = Gravity.CENTER;
        t.topMargin = dp(110);
        t.leftMargin = dp(24);
        t.rightMargin = dp(24);
        overlay.addView(status, t);

        setContentView(root);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openImportPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/zip");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void openExportPicker() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE, "deepseek-harness-workspace.zip");
        startActivityForResult(intent, REQ_EXPORT);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                android.util.Log.d("DshWeb", message.message() + " @" + message.lineNumber());
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                retryCount = 0;
                hideLoading();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()
                        && HARNESS_URL.equals(request.getUrl().toString())) {
                    showLoading("Harness 正在本机启动…");
                    scheduleRetry();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if ("127.0.0.1".equals(host) || "localhost".equals(host)) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
        });
    }

    private void startHarness() {
        showLoading("正在解压本机 Node.js / DeepSeek Harness 运行环境…");
        Thread worker = new Thread(() -> {
            try {
                File runtime = RuntimeInstaller.install(this);
                File bootstrap = new File(runtime, "bootstrap.mjs");
                if (!bootstrap.isFile()) {
                    throw new IllegalStateException("bootstrap.mjs missing from runtime");
                }

                if (NODE_STARTED.compareAndSet(false, true)) {
                    Thread nodeThread = new Thread(() -> {
                        int code = NodeBridge.startNodeWithArguments(new String[]{
                                "node",
                                bootstrap.getAbsolutePath(),
                                getFilesDir().getAbsolutePath()
                        });
                        runOnUiThread(() -> {
                            if (code != 0) {
                                showFatal("本机 Node.js / Harness 已退出，代码：" + code);
                            }
                        });
                    }, "embedded-node");
                    nodeThread.setDaemon(false);
                    nodeThread.start();
                }

                runOnUiThread(() -> {
                    showLoading("正在连接本机 Harness…");
                    webView.loadUrl(HARNESS_URL);
                    scheduleRetry();
                });
            } catch (Throwable e) {
                NODE_STARTED.set(false);
                runOnUiThread(() -> showFatal("启动失败：\n" + e));
            }
        }, "runtime-installer");
        worker.start();
    }

    private void scheduleRetry() {
        handler.removeCallbacksAndMessages("harness-retry");
        handler.postAtTime(() -> {
            if (webView.getVisibility() == View.VISIBLE) {
                retryCount++;
                if (retryCount > 60) {
                    showFatal("Harness 本机服务仍未就绪。请从“重新加载”再试，"
                            + "并通过 adb logcat 搜索 DshNode / DshWeb 获取日志。");
                    return;
                }
                webView.loadUrl(HARNESS_URL);
            }
        }, "harness-retry", android.os.SystemClock.uptimeMillis() + 1000);
    }

    private void showLoading(String message) {
        View overlay = findLoadingOverlay();
        if (overlay != null) overlay.setVisibility(View.VISIBLE);
        status.setText(message);
        progress.setVisibility(View.VISIBLE);
    }

    private void hideLoading() {
        View overlay = findLoadingOverlay();
        if (overlay != null) overlay.setVisibility(View.GONE);
    }

    private View findLoadingOverlay() {
        View root = webView.getParent() instanceof View ? (View) webView.getParent() : null;
        if (!(root instanceof ViewGroup)) return null;
        ViewGroup group = (ViewGroup) root;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if ("loading-overlay".equals(child.getTag())) return child;
        }
        return null;
    }

    private void showFatal(String message) {
        showLoading(message);
        progress.setVisibility(View.GONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_IMPORT) {
            new Thread(() -> {
                try {
                    WorkspaceZip.importZip(getContentResolver(), uri, workspace);
                    runOnUiThread(() -> Toast.makeText(this,
                            "项目已导入工作区", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    runOnUiThread(() -> new AlertDialog.Builder(this)
                            .setTitle("导入失败")
                            .setMessage(e.toString())
                            .setPositiveButton("确定", null)
                            .show());
                }
            }, "workspace-import").start();
        } else if (requestCode == REQ_EXPORT) {
            new Thread(() -> {
                try {
                    WorkspaceZip.exportZip(getContentResolver(), uri, workspace);
                    runOnUiThread(() -> Toast.makeText(this,
                            "工作区 ZIP 已导出", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    runOnUiThread(() -> new AlertDialog.Builder(this)
                            .setTitle("导出失败")
                            .setMessage(e.toString())
                            .setPositiveButton("确定", null)
                            .show());
                }
            }, "workspace-export").start();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
