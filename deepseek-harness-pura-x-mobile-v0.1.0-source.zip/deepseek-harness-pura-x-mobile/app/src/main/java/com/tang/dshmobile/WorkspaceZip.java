package com.tang.dshmobile;

import android.content.ContentResolver;
import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

final class WorkspaceZip {
    private WorkspaceZip() {}

    static void importZip(ContentResolver resolver, Uri uri, File workspace) throws IOException {
        if (!workspace.mkdirs() && !workspace.isDirectory()) {
            throw new IOException("Cannot create workspace: " + workspace);
        }
        String root = workspace.getCanonicalPath() + File.separator;
        try (InputStream in = resolver.openInputStream(uri);
             ZipInputStream zin = new ZipInputStream(new BufferedInputStream(in))) {
            ZipEntry e;
            byte[] buffer = new byte[64 * 1024];
            while ((e = zin.getNextEntry()) != null) {
                File out = new File(workspace, e.getName());
                String canonical = out.getCanonicalPath();
                if (!canonical.startsWith(root)) {
                    throw new IOException("Unsafe ZIP entry: " + e.getName());
                }
                if (e.isDirectory()) {
                    if (!out.mkdirs() && !out.isDirectory()) {
                        throw new IOException("Cannot create: " + out);
                    }
                } else {
                    File parent = out.getParentFile();
                    if (parent != null && !parent.mkdirs() && !parent.isDirectory()) {
                        throw new IOException("Cannot create: " + parent);
                    }
                    try (OutputStream bout = new BufferedOutputStream(new FileOutputStream(out))) {
                        int n;
                        while ((n = zin.read(buffer)) != -1) {
                            bout.write(buffer, 0, n);
                        }
                    }
                }
                zin.closeEntry();
            }
        }
    }

    static void exportZip(ContentResolver resolver, Uri uri, File workspace) throws IOException {
        try (OutputStream out = resolver.openOutputStream(uri);
             ZipOutputStream zout = new ZipOutputStream(new BufferedOutputStream(out))) {
            addTree(zout, workspace, workspace);
        }
    }

    private static void addTree(ZipOutputStream zout, File root, File current) throws IOException {
        File[] children = current.listFiles();
        if (children == null) return;
        byte[] buffer = new byte[64 * 1024];

        for (File child : children) {
            String rel = root.toPath().relativize(child.toPath()).toString().replace(File.separatorChar, '/');
            if (child.isDirectory()) {
                zout.putNextEntry(new ZipEntry(rel + "/"));
                zout.closeEntry();
                addTree(zout, root, child);
            } else {
                zout.putNextEntry(new ZipEntry(rel));
                try (InputStream in = new BufferedInputStream(new FileInputStream(child))) {
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        zout.write(buffer, 0, n);
                    }
                }
                zout.closeEntry();
            }
        }
    }
}
